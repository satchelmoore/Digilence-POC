
from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.responses import HTMLResponse
import tempfile
import os
from file_converter import doc_to_text  # Import doc_to_text function from doc_converter.py
from txtchunking import chunk_text, flatten_chunked_sentences
from messages_operations import add_message
from AzureOp import send_chat_message
app = FastAPI()

@app.post("/upload/")
async def upload_doc(file: UploadFile = File(...), question: str = Form(None)):
    try:
        # Save the uploaded file locally
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(await file.read())
            tmp.close()
            tmp_path = tmp.name

        # Convert DOC file to text using imported function
        text = doc_to_text(tmp_path)

        # Delete the temporary file
        os.remove(tmp_path)

        if text:
            #Gramamr Data
            grammar = """
    NP: {<DT>?<JJ>*<NN>}  # Chunk determiners, adjectives, and nouns
        {<NNP>+}          # Chunk sequences of proper nouns
""" 
            chunked = chunk_text(text, grammar)
           
            flattened = flatten_chunked_sentences(chunked)
            conversation=[]
            for sentence in flattened:
                conversation=add_message(conversation, "user", sentence)
            # Prepare the response dictionary
            response_data = {"text": conversation}

            # If a question was provided, include it in the response
            if question:
                conversation=add_message(conversation, "user", question)
                for i in conversation:
                    chunked_conversation=[]
                    chunked_conversation.append(i)
                    azure_data=send_chat_message(chunked_conversation).choices[0].message.content
                response_data["question"] = question
                if azure_data:
                    response_data["answer"] = azure_data
            return response_data
        else:
            raise HTTPException(status_code=500, detail="Failed to convert DOC file to text.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
